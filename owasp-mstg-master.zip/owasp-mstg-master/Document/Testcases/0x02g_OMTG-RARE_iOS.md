### <a name="OMTG-RARE-001"></a>OMTG-RARE-001: Test the Custom Keyboard

#### White-box Testing

#### Black-box Testing

#### References
