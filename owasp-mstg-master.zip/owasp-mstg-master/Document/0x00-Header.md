#

![OWASP LOGO](images/OWASP_logo.png)

# Mobile Application Security Testing Guide

[date]
