## Attribution (authors from Google Doc)

### Android Application Overview

Adapted from MSTG Beta 2:

Author - Dennis Titze, Stephanie Vanroelen, Anantshri
Reviewer - Anantshri

### iOS Application Overview

Adapted from MSTG Beta 2:

Author - Stephen Corbiaux
Reviewer - Pragati singh, Tom Neaves

### OMTG-DATAST-009: Test for Sensitive Data in Backups

Adapted from MSTG Beta 2:

Author - Shiv Patel
Contributors & Reviewers - Bernhard Wagner, Anant


### Reverse Engineering And Tampering

Android - adapted some content from MSTG Beta 2:

Author - Dennis Titze
Contributors & Reviewers - Anant, Bao Le

iOS - dapted some content from MSTG Beta 2:

Authors - Pragati Singh, Milan Singh Thakur
Contributors & Reviewers - Abhinav Sejpal,

### OMTG-NET-004: Test SSL Pinning

Adapted from MSTG Beta 2:

Authors - Davide Cioccia, Gerhard Wagner
